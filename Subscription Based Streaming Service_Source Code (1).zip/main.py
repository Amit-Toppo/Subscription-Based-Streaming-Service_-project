from Admin import admin_menu
from user import user_menu

def main():
    while True:
        print("\n|---------------------- Welcome to the Subscription Based Streaming Service ----------------------|")
        print("\nAre you an Admin or a User?")
        print("Press 1 for Admin")
        print("Press 2 for User")
        print("Press 3 to Exit")

        choice = input("\nEnter your choice: ").strip()

        if choice == "1":
            admin_menu()  # Admin menu runs but does not loop infinitely
        elif choice == "2":
            user_menu()  # User menu runs
        elif choice == "3":
            print("\nExiting Program. Goodbye!")
            break
        else:
            print("\nInvalid Choice! Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()  # Runs the main function

