import oracledb


# Function to view available subscriptions
def view_subscriptions(cursor):
    print("\nAvailable Subscription Plans:")
    cursor.execute("SELECT * FROM subscription")
    for row in cursor.fetchall():
        print(row)


# Function to subscribe/unsubscribe
def manage_subscription(cursor, conn):
    email = input("Enter your Email: ")
    action = input("Do you want to Subscribe or Unsubscribe? (S/U): ").strip().lower()

    if action == "s":
        subscription_type = input("Enter Subscription Type: ")
        cursor.execute("UPDATE users SET SubscriptionType = :1 WHERE Email = :2", (subscription_type, email))
        conn.commit()
        print("✅ Subscription Updated Successfully!")
    elif action == "u":
        cursor.execute("UPDATE users SET SubscriptionType = NULL WHERE Email = :1", (email,))
        conn.commit()
        print("✅ Unsubscribed Successfully!")
    else:
        print("❌ Invalid choice!")


import webbrowser

import webbrowser

def watch_content(cursor, conn):
    # **Step 1: Show Available Content**
    cursor.execute("SELECT ContentID, Title, Genre, Content_duration, ReleaseDate FROM ContentLibrary")
    content_list = cursor.fetchall()

    if content_list:
        print("\n|------ Available Content ------|")
        print("ContentID | Title                         | Genre          | Duration | Release Date ")
        print("-" * 80)
        for content in content_list:
            print(f"{content[0]:<9} | {content[1]:<30} | {content[2]:<12} | {content[3]:<8} | {content[4]}")
    else:
        print("\nNo content available.")
        return  # Exit function if no content is available

    # **Step 2: Ask for Content ID**
    content_id = input("\nEnter Content ID to Watch: ")

    # **Step 3: Fetch Content Title from Database**
    cursor.execute("SELECT Title FROM ContentLibrary WHERE ContentID = :1", (content_id,))
    result = cursor.fetchone()

    if result:
        content_title = result[0]
        youtube_search_url = f"https://www.youtube.com/results?search_query={content_title.replace(' ', '+')}"
        print(f"\nSearching on YouTube: {youtube_search_url}")
        webbrowser.open(youtube_search_url)  # Opens YouTube search results

        # **Step 4: Store Watch History Using UserID**
        user_id = input("\nEnter your User ID to record watch history: ")
        cursor.execute("INSERT INTO Streaming_History (UserID, ContentID, WatchTime, DateWatched) VALUES (:1, :2, 0, SYSDATE)", (user_id, content_id))
        conn.commit()

        print("Enjoy your show!")
    else:
        print("\nInvalid Content ID. Please try again.")



# Function to view subscription details
def view_subscription_details(cursor):
    email = input("Enter your Email: ")
    cursor.execute("SELECT SubscriptionType FROM Users WHERE Email = :1", (email,))
    result = cursor.fetchone()

    if result:
        print(f"Your Subscription: {result[0]}")
    else:
        print("❌ No subscription found!")


# User Menu Function
def user_menu():
    conn = oracledb.connect("sys/harshit29@localhost:1521/ORCLPDB", mode=oracledb.SYSDBA)
    cursor = conn.cursor()

    while True:
        print("\n|----------------------Welcome USER----------------------|")
        print("Press 1 To View Available Subscriptions")
        print("Press 2 To Subscribe/Unsubscribe")
        print("Press 3 To Watch Content")
        print("Press 4 To View Subscription Details")
        print("Press 5 To Exit")

        choice = input("\nEnter your choice: ").strip()

        if choice == "1":
            view_subscriptions(cursor)
        elif choice == "2":
            manage_subscription(cursor, conn)
        elif choice == "3":
            watch_content(cursor, conn)
        elif choice == "4":
            view_subscription_details(cursor)
        elif choice == "5":
            print("\n✅ Exiting User Menu...")
            break
        else:
            print("\n❌ Invalid Choice! Please enter a valid option.")

    cursor.close()
    conn.close()


# Run the User Menu
if __name__ == "__main__":
    user_menu()
