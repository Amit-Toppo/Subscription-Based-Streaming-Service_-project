import csv
import oracledb

# Database Connection
conn = oracledb.connect("sys/harshit29@localhost:1521/ORCLPDB", mode=oracledb.SYSDBA)
cursor = conn.cursor()

# Define CSV File Name
csv_filename = "streaming_data.csv"

# List of Tables to Export
tables = ["Users", "Subscription", "ContentLibrary", "Streaming_History", "Payment"]
import os
print("Current Working Directory:", os.getcwd())  # This shows where the script is running
def export_to_csv():
    with open(csv_filename, mode="w", newline="") as file:
        writer = csv.writer(file)

        for table in tables:
            # Fetch Data from Each Table
            cursor.execute(f"SELECT * FROM {table}")
            rows = cursor.fetchall()
            columns = [col[0] for col in cursor.description]  # Get Column Names

            # Write Table Name as Header
            writer.writerow([f"--- {table} ---"])
            writer.writerow(columns)  # Write Column Names
            writer.writerows(rows)  # Write Data
            writer.writerow([])  # Blank line for separation

    print(f"\n✅ Data exported successfully to '{csv_filename}'!")


# Run Export Function
export_to_csv()

# Close Connection
cursor.close()
conn.close()
