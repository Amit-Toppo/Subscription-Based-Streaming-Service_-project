import oracledb

# Database Connection
conn = oracledb.connect("sys/harshit29@localhost:1521/ORCLPDB", mode=oracledb.SYSDBA)
cursor = conn.cursor()

print("✅ Connected to Oracle DB!")

# 1. Add User Function
def add_user():
    user_name = input("Enter User Name: ")
    email = input("Enter Email: ")
    subscription = input("Enter Subscription Type: ")
    payment = input("Enter Payment Info: ")

    cursor.execute("INSERT INTO users (User_Name, Email, SubscriptionType, PaymentInfo) VALUES (:1, :2, :3, :4)",
                   (user_name, email, subscription, payment))
    conn.commit()
    print("✅ User added successfully!")

# 2. Delete user function
def delete_user():
    user_id = input("Enter User ID to Delete: ")

    # Check if the user exists before deleting
    cursor.execute("SELECT * FROM Users WHERE UserID = :1", (user_id,))
    user = cursor.fetchone()

    if user:
        confirm = input(f"Are you sure you want to delete User ID {user_id}? (yes/no): ").strip().lower()
        if confirm == "yes":
            cursor.execute("DELETE FROM Users WHERE UserID = :1", (user_id,))
            conn.commit()
            print(f"User ID {user_id} deleted successfully!")
        else:
            print("Deletion cancelled.")
    else:
        print("User ID not found!")

# 3. Update User Details
def update_user():
    user_id = input("Enter User ID to update: ")
    # Check if the user exists
    cursor.execute("SELECT * FROM Users WHERE UserID = :1", (user_id,))
    user = cursor.fetchone()

    if user:
        print("\nSelect the field to update:")
        print("1 - User Name")
        print("2 - Email")
        print("3 - Subscription Type")
        print("4 - Payment Info")
        choice = input("\nEnter your choice: ")

        if choice == "1":
            new_value = input("Enter new User Name: ")
            cursor.execute("UPDATE Users SET User_Name = :1 WHERE UserID = :2", (new_value, user_id))
        elif choice == "2":
            new_value = input("Enter new Email: ")
            cursor.execute("UPDATE Users SET Email = :1 WHERE UserID = :2", (new_value, user_id))
        elif choice == "3":
            new_value = input("Enter new Subscription Type (Basic/Premium/VIP): ")
            cursor.execute("UPDATE Users SET SubscriptionType = :1 WHERE UserID = :2", (new_value, user_id))
        elif choice == "4":
            new_value = input("Enter new Payment Info (UPI/Credit Card/Debit Card): ")
            cursor.execute("UPDATE Users SET PaymentInfo = :1 WHERE UserID = :2", (new_value, user_id))
        else:
            print("Invalid choice! No updates made.")
            return

        conn.commit()
        print("User details updated successfully!")
    else:
        print("User ID not found!")

def display_all_users():
    # Fetch all users
    cursor.execute("SELECT * FROM Users")
    users = cursor.fetchall()

    if users:
        print("\n|------ List of All Users ------|")
        print("UserID | User Name | Email | Subscription Type | Payment Info")
        print("-" * 60)
        for user in users:
            print(f"{user[0]:<6} | {user[1]:<10} | {user[2]:<20} | {user[3]:<15} | {user[4]:<12}")
    else:
        print("No users found in the database.")
# 4. Add subscription
def add_subscription():
    user_id = input("Enter User ID to assign a subscription: ")
    # Check if the user exists
    cursor.execute("SELECT * FROM Users WHERE UserID = :1", (user_id,))
    user = cursor.fetchone()

    if user:
        plan_type = input("Enter Subscription Plan (Basic/Premium/VIP): ")
        start_date = input("Enter Start Date (YYYY-MM-DD): ")
        end_date = input("Enter End Date (YYYY-MM-DD): ")

        cursor.execute("""
            INSERT INTO Subscription (UserID, PlanType, StartDate, EndDate)
            VALUES (:1, :2, TO_DATE(:3, 'YYYY-MM-DD'), TO_DATE(:4, 'YYYY-MM-DD'))
        """, (user_id, plan_type, start_date, end_date))

        conn.commit()
        print(f"Subscription for User ID {user_id} added successfully!")
    else:
        print("User ID not found!")
# 5. Cancel Subscription
def cancel_subscription():
    user_id = input("Enter User ID to cancel the subscription: ")

    # Check if the subscription exists
    cursor.execute("SELECT * FROM Subscription WHERE UserID = :1", (user_id,))
    subscription = cursor.fetchone()

    if subscription:
        confirm = input(f"Are you sure you want to cancel the subscription for User ID {user_id}? (yes/no): ").strip().lower()
        if confirm == "yes":
            cursor.execute("DELETE FROM Subscription WHERE UserID = :1", (user_id,))
            conn.commit()
            print(f"Subscription for User ID {user_id} has been cancelled successfully!")
        else:
            print("Cancellation aborted.")
    else:
        print("No active subscription found for this User ID!")

# 6. Process Payment
def process_payment():
    user_id = input("Enter User ID for payment processing: ")
    # Check if the user exists
    cursor.execute("SELECT * FROM Users WHERE UserID = :1", (user_id,))
    user = cursor.fetchone()

    if user:
        amount = input("Enter Payment Amount: ")
        payment_status = input("Enter Payment Status (Success/Failed/Pending): ")

        cursor.execute("""
            INSERT INTO Payment (UserID, Amount, PaymentStatus, PaymentDate)
            VALUES (:1, :2, :3, SYSDATE)
        """, (user_id, amount, payment_status))

        conn.commit()
        print(f"Payment of {amount} recorded for User ID {user_id} with status: {payment_status}.")
    else:
        print("User ID not found!")

# 7. Add Content
def add_content():
    title = input("Enter Content Title: ")
    genre = input("Enter Genre: ")
    duration = input("Enter Duration (in minutes): ")
    release_date = input("Enter Release Date (YYYY-MM-DD): ")
    cursor.execute("""
        INSERT INTO ContentLibrary (Title, Genre, Content_Duration, ReleaseDate)
        VALUES (:1, :2, :3, TO_DATE(:4, 'YYYY-MM-DD'))
    """, (title, genre, duration, release_date))

    conn.commit()
    print(f"Content '{title}' added successfully!")

# 8. Remove Content
def remove_content():
    content_id = input("Enter Content ID to remove: ")
    # Check if the content exists
    cursor.execute("SELECT * FROM ContentLibrary WHERE ContentID = :1", (content_id,))
    content = cursor.fetchone()

    if content:
        confirm = input(f"Are you sure you want to delete Content ID {content_id}? (yes/no): ").strip().lower()
        if confirm == "yes":
            cursor.execute("DELETE FROM ContentLibrary WHERE ContentID = :1", (content_id,))
            conn.commit()
            print(f"Content ID {content_id} removed successfully!")
        else:
            print("Deletion cancelled.")
    else:
        print("Content ID not found!")

# 9. View Streaming History
def view_streaming_history():
    # Fetch streaming history
    cursor.execute("SELECT * FROM Streaming_History ORDER BY DateWatched DESC")
    history = cursor.fetchall()

    if history:
        print("\n|------ Streaming History ------|")
        print("HistoryID | UserID | ContentID | WatchTime (min) | Date Watched")
        print("-" * 60)
        for record in history:
            print(f"{record[0]:<9} | {record[1]:<6} | {record[2]:<9} | {record[3]:<15} | {record[4]}")
    else:
        print("No streaming history found.")

    cursor.close()
    conn.close()

# Admin Menu Function
def admin_menu():
    while True:
        print("\n|----------------------Welcome ADMIN----------------------|")
        print("\nEnter Your Choice:\n")
        print("Press 1 To Add User")
        print("Press 2 To Delete User")
        print("Press 3 To Update User Details")
        print("Press 4 To Display All Users")
        print("Press 5 To Add Subscription")
        print("Press 6 To Cancel Subscription")
        print("Press 7 To Process Payment")
        print("Press 8 To Add Content")
        print("Press 9 To Remove Content")
        print("Press 10 To View Streaming History")
        print("Press 0 To Exit")

        choice = input("\nEnter your choice: ").strip()

        if choice == "1":
            add_user()  # ✅ Call the function to add user
        elif choice == "2":
            delete_user()
        elif choice == "3":
            update_user()
        elif choice == "4":
            display_all_users()
        elif choice == "5":
            add_subscription()
        elif choice == "6":
            cancel_subscription()
        elif choice == "7":
            process_payment()
        elif choice == "8":
            add_content()
        elif choice == "9":
            remove_content()
        elif choice == "10":
            view_streaming_history()
        elif choice == "0":
            print("\n✅ Exiting... Goodbye!")
            return
        else:
            print("\n❌ Invalid Choice! Please enter a valid option.")











